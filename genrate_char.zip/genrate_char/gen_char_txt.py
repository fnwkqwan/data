# 本程序是用于生成OCR-set文件，其作用是将字符与label组成键值对,如：ID:char
# 用于后续生成字符训练样本

import os
import pickle
from os.path import exists

file = open("OCR-set.txt", 'w', encoding='utf-8')

i = 0

w_string = ''
for j in range(ord("A"), ord("Z")+1):
    w_string = str(i).zfill(3) + ':' + chr(j) + '\n'
    file.write(w_string)
    i = i + 1


for j in range(0, 10):
    w_string = str(i).zfill(3) + ':' + chr(j + ord('0')) + '\n'
    file.write(w_string)
    i = i + 1

w_string = str(i).zfill(3) + ':' + chr(ord('-')) + '\n'
file.write(w_string)
i = i + 1

file.close()

# 将上述生成的文件读入并存入字典
txt_dict = {}
fopen = open("OCR-set.txt", 'r')
for line in fopen.readlines():
    line = str(line).replace("\n", "")  # 注意，必须是双引号，找了大半个小时，发现是这个问题。。
    txt_dict[line.split(':', 1)[0]] = line.split(':', 1)[1]
    # split（）函数用法，逗号前面是以什么来分割，后面是分割成n+1个部分，且以数组形式从0开始
    # 初学python，感觉这样表达会理解一点。。
fopen.close()
print(len(txt_dict))

# 使用pickle.dump将字典内容序列化输出
file2 = open("OCR-sets.txt", 'wb')
pickle.dump(txt_dict, file2)
file2.close()
